<html>
<body>

You have chosen <?php 
echo $_POST['ssidnama']; ?>

</body>
</html>